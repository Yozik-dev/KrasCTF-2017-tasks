module Model exposing (..)

import Time exposing (Time)
import Set

import Model.Ui exposing (..)
import Model.Scene exposing (..)


type alias Model =
  { ui : Ui
  , scene : Scene
  , secondsPassed : Int
  , urlListen : String
  , urlSend : String
  , gameTime : Float
  , salt : String}


freshGame : Ui -> Model
freshGame ui =
  let
      ui_ = { ui | screen = PlayScreen
                 , pressedKeys = Set.empty }
  in
      { initialModel | ui = ui_ }

initialModel : Model
initialModel =
  { ui = initialUi
  , scene = initialScene
  , secondsPassed = 0
  , urlListen = "?????"
  , urlSend = "?????"
  , gameTime = 0
  , salt = "?????" }
